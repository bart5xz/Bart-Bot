const client = require('..');
const chalk = require('chalk');
const ms = require('ms')

client.on("ready", () => {
    
    
client.user.setActivity("/help | BartBot.gg", {
  type: 1,
  url: "https://www.twitch.tv/monstercat"
});


	console.log(chalk.white(`[BartBot] Iniciado!`))
	
});