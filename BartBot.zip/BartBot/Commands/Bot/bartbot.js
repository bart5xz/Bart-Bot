const { EmbedBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, ButtonBuilder, ButtonStyle  } = require('discord.js')
const Discord = require('discord.js');
const { durationTime } = require('util-stunks')  
const moment = require("moment")
require("moment-duration-format")


module.exports = {
    name: "bartbot",
    description: "｢Bot｣ Exibe informações do bot.",
    type: Discord.ApplicationCommandOptionType.ChatInput,




    run: async(client, interaction) => {

        
        const ping = Math.round(client.ws.ping)
      const gateway = Date.now() - interaction.createdTimestamp 
      let membros = client.users.cache.size;
      let servidor = client.guilds.cache.size;
      let vscode = "https://code.visualstudio.com"
      let js = "https://www.javascript.com"
      const up = moment.duration(client.uptime).format(" D [Dias], H [Horas], m [Minutos]");
      let canais = client.channels.cache.size;


      const server = interaction.guild.members.cache.get(client.user.id)


        let botinfoembed = new EmbedBuilder()
         .setTitle(`${client.user.username}`)
         .setDescription(`*👋  Olá, me chamo ${client.user.username}! e eu sou um Bot de moderação, e para ser criado eu fui usado em um aplicativo chamado [Visual Studio Code](${vscode})  <:Visual_Studio_Code_1:1050518725473878076> e na linguagem [JavaScript](${js})  <:js:1041692115396218942> e abaixo tem algumas outras informaçoes importantes sobre mim!\ninformações sobre mim:*`)
         .setColor('Black')
         .setThumbnail(`${client.user.displayAvatarURL()}`)
         .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})
         .addFields(
            {
                name: '🏓 | Ping:',
                value: `\`\`\`Ping: ${ping}\`\`\``,
                inline: false,

            },
            {
                name: '<:IconID:1050518904365129811> | ID:',
                value: `\`\`\`${client.user.id}\`\`\``,
                inline: false,
                
            },
            {
                name: '📅 | Entrou no Servidor:',
                value: `<t:${Math.ceil(server.joinedTimestamp / 1000)}:F>`,
                inline: false,
            },
            {
                name: `📆 | Criado:`,
                value: `<t:${parseInt(client.user.createdTimestamp / 1000)}>`,
                inline: false,
            },
            {
                name: '<:timer:1049050546822197298> | Tempo no Discord:',
                value: `\`\`\`${durationTime(client.user.createdTimestamp, 
                { removeMs: true, displayAtMax: 3 })}\`\`\``,
             },
             {
                name: '🤖 | Me adicione:',
                value: `[Link de convite](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=0&scope=bot%20applications.commands)`,
                inline: false,
             },
             {
                name: '<:Badge_Bot:1050521996716421120> | Para saber todos os meus comandos:',
                value: `\`\`\`Digite /help\`\`\``,
                inline: false,
             }
         
               
         )

         const selectBOT = new ActionRowBuilder()
          .addComponents(
            new Discord.SelectMenuBuilder()
            .setCustomId('select2')
            .setPlaceholder('⚡ Opções')
            .addOptions(
                {
                    label: 'Cargos',
                    description: 'Clique aqui para ver os cargos do Bot!',
                    emoji: '<:configuracoes:1041069267476561971>',
                    value: 'cargos',
                },
                {
                    label: 'Invite',
                    description: 'Clique aqui para receber o link de convite do bot!',
                    emoji: '<:8512blurplelink:1050518618204540949>',
                    value: 'config',
                },

                
            ),
            
          )

         

         interaction.reply({  content: `${interaction.user}`, embeds: [botinfoembed], components: [selectBOT] })
    }
}