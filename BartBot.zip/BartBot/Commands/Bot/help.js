const { SelectMenuBuilder, ActionRowBuilder, EmbedBuilder } = require('discord.js')

const fs = require('fs')



module.exports = {

    name: 'help',

    description: '｢Bot｣ Mostra meu painel de ajuda.',

    run: async (client, interaction) => {



        const optionsArr = []



        const commandsFolder = fs.readdirSync('./Commands')

        for (const category of commandsFolder) {

            optionsArr.push({ label: `${category}`, description: `Veja os comandos de ${category}`, value: `${category}` })

        }



        const embed = new EmbedBuilder()
        
        .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})

        .setTitle('<:staff:1048689586454405130>  |  Central de Ajuda Bart Bot!')

        .setColor('Black')

        .setDescription(`<:XmasSantaHat:1054736186247237663> | 👋 Olá ${interaction.user} veja alguns links importantes abaixo:\n\n> **[Me adicione em seu servidor](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=0&scope=bot%20applications.commands)**\n> **[Entre no meu servidor de support](https://discord.gg/eYkRqWZNuF)**

\n> <a:raio_azul:1041070320125235302> | Veja minhas novidades e atualizações com \`/news\`!\nMinhas categorias estao divididas em \`｢｣\` dando pra identificar facilmente os comandos!

\n> <:8512blurplelink:1050518618204540949> | Para abrir meu painel de invite use \`/convites\`!

\n> <:configuracoes:1041069267476561971> | *Para obter ajuda selecione uma categoria abaixo!*`)



        const menu = new ActionRowBuilder()

        .setComponents(

            new SelectMenuBuilder()

            .setCustomId('menu-help')

            .addOptions(optionsArr)

        )



        await interaction.reply({ embeds: [embed], components: [menu] }).then(async (msg) => {

            const filter = (m) => m.user.id == interaction.user.id

            const collector = msg.createMessageComponentCollector({ filter, time: 60000 })



            collector.on('collect', async (i) => {

                i.deferUpdate();

                const selected = i.values[0]

                const commandsArr = []

                const commandsFiles = fs.readdirSync(`./Commands/${selected}`)



                for (const command of commandsFiles) {

                    if (command.endsWith('.js')) {

                        commandsArr.push(command.replace(/.js/g, ''))

                    }

                }



                embed.setDescription(`<:XmasSantaHat:1054736186247237663> | Veja todos os comandos da categoria ${selected}`)

                embed.setFields([

                    { name: 'Comandos <:Badge_Bot:1050521996716421120>', value: `\`\`\`${commandsArr.join(', ')}\`\`\`` }

                ])



                interaction.editReply({ embeds: [embed] })

            })

        })



    }

}