const Discord = require('discord.js')

module.exports = {
    name: "convites",
    description: "｢Bot｣  Abra meu painel de convites uteis.",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        
        let convite = "https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot"
        let servidor = "https://discord.gg/4NBrVkHKkR"
        
        
        const embed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})
        .setTitle(`Meus links de convites`)
        .setColor(`Black`)
        .setDescription(`**👋 Olá ${interaction.user}, esse e um painel de convites para que voce possa me adicionar em seu servidor ou entrar no meu servidor de support e ajuda!**

*Meus links de convites:*

> [Me adicione em seu servidor](${convite})
> [Entre no meu servidor de support](${servidor})

> E nao se esqueca, para ver minhas atualizacoes use \`\`\/novidades\`\`\!`)
        .setThumbnail(`${client.user.displayAvatarURL()}`)
        .setTimestamp()

        interaction.reply({ embeds: [embed] })
    }
}
