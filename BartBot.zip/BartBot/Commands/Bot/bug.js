const Discord = require('discord.js')

module.exports = {
    name: 'reportarbug',
    description: '｢Utilidades｣ Reporte um bug ao desenvolvedor do bot',
    type: Discord.ApplicationCommandType.ChatInput,
    options: [{
        name: 'bug',
        description: 'Escreva o bug que deseja reportar',
        type: Discord.ApplicationCommandOptionType.String,
        required: true
    }],
    run: async(client, interaction) => {


        let bug = interaction.options.getString('bug')
        let channel = client.channels.cache.get('1048627037885186048') // ID do canal onde será enviado o report

        interaction.reply({
            embeds: [new Discord.EmbedBuilder()
                .setColor('#5765F2')
                .setDescription('<a:seta2:1049036671011794974> **|** Bug reportado com sucesso!')
            ], ephemeral: true
        })

        channel.send({ embeds: [new Discord.EmbedBuilder()
            .setColor('#5765F2')
            .setTitle('<:staff:1048689586454405130> | Novo bug Reportado!')
            .setDescription(`<:1129discord:1050518640665034752> | Servidor: ${interaction.guild.name}\n
            <:6055blurpleinvite:1050519520986546196> | User:\n
<:IconID:1050518904365129811> | ID: \`${interaction.user.id}\`\n
<:8263blurplemembers:1050518613850861649> | Tag: \`${interaction.user.tag}\`\n
<:9098blurpleannouncements:1050519586879053874> | Menção: ${interaction.user}\n\n
<a:seta2:1049036671011794974> | Bug Reportado:\n
            ${bug}`)
        ]})


    }
} 
