const Discord = require("discord.js");

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandType, ButtonStyle } = require('discord.js');



module.exports = {

    name: "novidades",

    description: "｢Bot｣ Veja as novidades e atualizações novas do Bot.",

    type: Discord.ApplicationCommandType.ChatInput,



    run: async (client, interaction) => {



        

        const embed = new Discord.EmbedBuilder()
        
        .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})

        .setTitle(`<:XmasSantaHat:1054736186247237663> Minhas Atualizações e Novidades!`)

        .setColor('#5765F2')

        .setDescription(`
        
> 👋 Olá ${interaction.user},
        
Você deseja saber minhas últimas notícias e novidades certo? Então continue lendo.
Atualmente estou apenas respondendo aos comandos em \`\`\Slash (/)\`\`\.
Utilize \`\`\/help\`\`\ para ver meus comandos. Caso meus comandos em Slash não estejam aparecendo ou estão indisponíveis, me adicione novamente no servidor clicando abaixo!
        
> <:expStarFull:1055074236613525564> | *Atualizações: Comandos aprimorados, comandos editados com melhor designer, adição de mais mais 3 comandos, bugs resolvidos, temáticas de Natal estão a ser adicionadas, nova funcao de ver as badges do usuario selecionado usando /userinfo.*

> <:expEducation:1055074057260892162> | *Para receber cursos completos e gratuitos use \`\`\/cursos\`\`\!*

> <:expAttachment:1055074110973157396> | *Comandos Novos: /novidades, /cursos, /nitro, /badges, /convites.*
        
> <:expCreateEvent:1055074176433659944> | Ultima atualização: \`\`\(22/12/2022)\`\`\ `)



        .setTimestamp()



        const ButtonNews = new ActionRowBuilder()

        .addComponents([

          new ButtonBuilder()

            .setEmoji('<:8512blurplelink:1050518618204540949>')

            .setLabel('Convite')

            .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=applications.commands%20bot`)

            .setStyle(ButtonStyle.Link)

        ])



        interaction.reply({ embeds: [embed], components: [ButtonNews] })

    }

}

