const Discord = require("discord.js")//vendo bots no pv Bruno7#8084



module.exports = {//vendo bots no pv Bruno7#8084

  name: "ping", // Coloque o nome do comando//vendo bots no pv Bruno7#8084

  description: "｢Bot｣ Veja o ping do bot.", // Coloque a descrição do comando //vendo bots no pv Bruno7#8084

  type: Discord.ApplicationCommandType.ChatInput,//vendo bots no pv Bruno7#8084



  run: async (client, interaction) => {//vendo bots no pv Bruno7#8084



    let ping = client.ws.ping;//vendo bots no pv Bruno7#8084



    let embed_1 = new Discord.EmbedBuilder()

    .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) })//vendo bots no pv Bruno7#8084

    .setDescription(`<:XmasSantaHat:1054736186247237663> Olá ${interaction.user}, Nesse exato momento eu estou \`calculando.\` minha latenca...`)//vendo bots no pv Bruno7#8084

    .setColor("#5765F2");//vendo bots no pv Bruno7#8084



    let embed_2 = new Discord.EmbedBuilder()

    .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) })//vendo bots no pv Bruno7#8084
    
    .setTitle(`Ping Calculado!`)

    .setDescription(`${interaction.user}, Meu ping está em \`${ping}ms\`!\nE eu demorei exatos \`${(Date.now() - interaction.createdTimestamp) / 5**(1)}ms\` para responder a sua mensagem!` )//vendo bots no pv Bruno7#8084
    
    .setTimestamp()

    .setColor("#5765F2");//vendo bots no pv Bruno7#8084



    interaction.reply({ embeds: [embed_1] }).then( () => {//vendo bots no pv Bruno7#8084

        setTimeout( () => {//vendo bots no pv Bruno7#8084

            interaction.editReply({ embeds: [embed_2] })//vendo bots no pv Bruno7#8084

        }, 2000)//vendo bots no pv Bruno7#8084

    })//vendo bots no pv Bruno7#8084

  }//vendo bots no pv Bruno7#8084

}//vendo bots no pv Bruno7#8084