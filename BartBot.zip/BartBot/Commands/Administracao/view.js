const Discord = require("discord.js")



module.exports = {

    name: "lock-view",

    description: "｢Administracao｣  Desabilitar a função ver canal para everyone",

    type: Discord.ApplicationCommandType.Type,





    run: async (client, interaction, args) => {





        if (!interaction.member.permissions.has("ADMINISTRATOR"))    {

            interaction.reply(`⚡⚡ Opa ${interaction.user}, Você não tem os cargos necessários para utilizar esse comando!`)

        } else {

let embed = new Discord.EmbedBuilder()


                .setColor('#5765F2')

                .addFields({name: `Visualizaçao do canal para membros normal foi bloqueada para desbloquear use  \`\`\/unlock-view\`\`\`!`, value: `📃 Ocultado por: ${interaction.user}`})

                interaction.reply({ embeds: [embed] }).then(msg => {

                interaction.channel.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: false }).catch(e => {

                    console.log(e)

                    interaction.editReply(`❌ O comando \`\`\`lock-view\`\`\` não foi executado com sucesso!`)

                })

            })

    

                }

            }        

    }

    

    