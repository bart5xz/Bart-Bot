const Discord = require("discord.js")

//Manda pedido pra mim pfv > luandev.ig#7496

module.exports = {

    name: "unlock", // Coloque o nome do comando do arquivo

    description: "｢Administracao｣  Desbloqueie um canal de texto.",

    type: Discord.ApplicationCommandType.ChatInput,

    

    run: async(client, interaction) => {

        if (!interaction.member.permissions.has("ManageChannels")) {

            interaction.reply(`Você não possui a permissão \`Gerenciar Canais\` para poder uttilizar este comando.`)

        } else {

            let destrancar = new Discord.EmbedBuilder()

            .setTitle("✅ Canal destrancado!")

            .addFields({name: `🔓 | Esse canal foi destrancado, agora todos poderão digitar novamente, para trancar use **/lock**`, value: `📃 Destrancado por: ${interaction.user}`})

            .setColor('#5D3FE8')

            interaction.reply({embeds: [destrancar]}).then(msg => { 

            interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: true }).catch(e => {

                console.log(e)

            

                msg.edit(`❌ Ops, algo deu errado ao tentar destrancar este chat.`)

            })

        })



            }//Manda pedido pra mim pfv > luandev.ig#7496

        }        

}//Créditos luandev.ig#7496