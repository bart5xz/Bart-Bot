const Discord = require("discord.js")



module.exports = {

    name: "unlock-view",

    description: "｢Administracao｣  habilita para todos os membros ver o canal!",

    type: Discord.ApplicationCommandType.Type,





    run: async (client, interaction, args) => {





        if (!interaction.member.permissions.has("ADMINISTRATOR"))    {

            interaction.reply(`❌  Você não possui a permissão \`Admistrador\` para executar o comando \`\`\`unlock-view\`\`\``)

        } else {

            let embed = new Discord.EmbedBuilder()


                .setColor('#5765F2')

                .addFields({name: `Canal Liberado para membros verem com sucesso para bloquear novamente use \`\`\/lock-view\`\`\`!`, value: `📃 Liberado por: ${interaction.user}`})

                interaction.reply({ embeds: [embed] }).then(msg => {

                interaction.channel.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: true }).catch(e => {

                    console.log(e)

                    interaction.editReply(`O comando \`\`\`unlock-unview\`\`\` não foi executado com sucesso`)

                })

            })

    

                }

            }        

    }

    

    