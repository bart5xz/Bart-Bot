const Discord = require("discord.js")

//Manda pedido pfv luandev.ig#7496

module.exports = {

    name: "lock",

    description: "｢Administracao｣  Tranca um canal de texto!",

    type: Discord.ApplicationCommandType.ChatInput,



    run: async (client, interaction, args) => {

        if (!interaction.member.permissions.has("ManageChannels")) {

            interaction.reply(`❌ | Você não possui a permissão \`Genrenciar Canais\` para poder uttilizar este comando!`)

        } else {

            let embed = new Discord.EmbedBuilder()

                .setTitle("✅ Canal trancado!")

                .setColor('#5D3FE8')

                .addFields({name: `🔒 | Esse canal foi trancado, apenas administradores poderão digitar aqui, para desbloquear use **/unlock**!`, value: `📃 Trancado por: ${interaction.user}`})

                interaction.reply({ embeds: [embed] }).then(msg => {

                interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: false }).catch(e => {

                    console.log(e)

                    interaction.editReply(`❌ Ops, algo deu errado ao tentar trancar este chat.`)

                })

            })

    

                }

            }        //Manda pedido no discord pra mim pfv? luandev.ig#7496

    }

    

    