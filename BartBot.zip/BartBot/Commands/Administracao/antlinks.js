const Discord = require("discord.js");

const { QuickDB } = require('quick.db')

const db = new QuickDB()



module.exports = {

    name: "antilink",

    description: '｢Administracao｣  Bloqueia todos os links enviados por membros sem permissão.',

    options: [

        {

            name: 'opção',

            description: 'Selecione uma opção.',

            type: Discord.ApplicationCommandOptionType.String,

            required: true,

            choices: [

                {

                    name: 'Ativar',

                    value: 'on',

                },

                {

                    name: 'Desativar',

                    value: 'off',

                }

            ],

        },

    ],





    run: async (client, interaction, args) => {

        const option = interaction.options.getString("opção")



        if (!interaction.channel.permissionsFor(interaction.user).has(Discord.PermissionFlagsBits.ManageGuild))

            return interaction.reply({

                content: `⚡⚡ Opa ${interaction.user}, Você não tem os cargos necessários para utilizar esse comando!`,

                ephemeral: true

            })



        if (option === "on") {

            db.set(`antilink_${interaction.guild.id}`, "on");

            interaction.reply({

                embeds: [

                    new Discord.EmbedBuilder()

                        .setTitle(`Ativado!`)

                        .setColor("#5765F2")


                        .setDescription(`<:emoji_43:1051253608169078784> | **${interaction.user},** O sistema de antilinks foi ativado com sucesso em **${interaction.guild.name}**`)

                ],

            });



        };

        if (option === "off") {



            db.set(`antilink_${interaction.guild.id}`, "off");

            interaction.reply({

                embeds: [

                    new Discord.EmbedBuilder()

                        .setTitle(`Desativado!`)

                        .setColor(`#5765F2`)


                        .setDescription(`<:emoji_42:1051253625017606174> | **${interaction.user},** O sistema de antilinks foi desativado com sucesso em **${interaction.guild.name}**`)



                  ],

            });

        };

    }

}