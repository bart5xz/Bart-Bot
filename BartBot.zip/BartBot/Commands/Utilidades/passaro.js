const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "bird",

    description: "｢Utilidades｣  Envie uma foto de um pássaro",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/bird`).then(response => response.json()).then(async(bird) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🐦 Passaro`)

     .setDescription(`[Que pássaro fofo](${bird.image}).`)

     .setImage(bird.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};