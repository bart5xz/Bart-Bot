const { ActionRowBuilder, EmbedBuilder, ButtonBuilder  } = require("discord.js");



module.exports = {

    name: "avatar",

    description: "｢Utilidades｣  Pegue um avatar de um usuario.",

    options: [

        {

            name: 'usuario',

            type: 6,

            description: 'Coloque o usuário para ver o avatar.',

            require: false

        },  

    ],

    run: async (client, interaction) => {



      let user = interaction.options.getUser('usuario') || interaction.user;



      

      const button = new ButtonBuilder()

      .setEmoji("<:emoji_50:1050561050744999946>")

      .setLabel(" Ver na Web")

      .setStyle(5)

      .setURL(

        user.displayAvatarURL({ dynamic: true, format: "png", size: 4096 })

      );



      const row = new ActionRowBuilder().addComponents(button);

 

      let avatar = user.displayAvatarURL({ dynamic: true, format: "png", size: 4096 })



        let embed = new EmbedBuilder()

       .setTitle(`<:8196blurpleimage:1050518611237797970> | Avatar do usuário ${user.username}👇`)

      .setColor('#5765F2')

      .setImage(avatar)



      interaction.reply({ embeds: [embed], components: [row] })

      

    }

}