const Discord = require("discord.js")

const { EmbedBuilder } = require("discord.js")

module.exports = {



    name : "url",//Nome do Commando

    description: "｢Utilidades｣  Veja o url personalizado do servidor.",// Descrição em "/".

    permission: "Aucune", // Permissão 

    dm: false, // Não funciona em DM

    async run(bot, message, args) {



        let Embed = new EmbedBuilder()

        .setColor("#5D3FE8") // Cor HTML

        .setTitle(`**<:8512blurplelink:1050518618204540949> | Url**`) // Titre (Vanity = URL Personnaliser+ )

        .setDescription(message.guild.vanityURLCode ?`*O URL personalizado do servidor é :* **${message.guild.vanityURLCode}**`: `*Esse servidor nao tem um url personalizado!*`)//Description avec condition si L'URL Personnaliser existe ou non

        .setFooter({ text: `📃 Execultado por ${interaction.user}`})//rodapé      

        .setTimestamp() // Tempo/Hora

 message.reply({embeds: [Embed]})// Resposta do bot pelo Embed

    }



}