const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "dog",

    description: "｢Utilidades｣  Envia a foto de um cachorro",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/dog`).then(response => response.json()).then(async(dog) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🐶 Cachorro`)

     .setDescription(`[Que cachorro fofo](${dog.image}).`)

     .setImage(dog.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};