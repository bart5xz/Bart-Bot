const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "fox",

    description: "｢Utilidades｣  Envia a foto de uma raposa",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/fox`).then(response => response.json()).then(async(fox) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🦊 Raposa`)

     .setDescription(`[Que raposa fofa](${fox.image}).`)

     .setImage(fox.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};