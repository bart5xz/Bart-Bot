const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "koala",

    description: "｢Utilidades｣  Envia a foto de um koala",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/koala`).then(response => response.json()).then(async(koala) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🐨 Coala`)

     .setDescription(`[Que coala fofo](${koala.image}).`)

     .setImage(koala.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};