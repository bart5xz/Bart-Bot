const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "canguru",

    description: "｢Utilidades｣  Envia a foto de um canguru",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/kangaroo`).then(response => response.json()).then(async(kangaroo) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🦘 Canguru`)

     .setDescription(`[Que canguru fofo](${kangaroo.image})`)

     .setImage(kangaroo.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};