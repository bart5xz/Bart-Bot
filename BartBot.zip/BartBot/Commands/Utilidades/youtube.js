const Discord = require("discord.js");



module.exports = {

    name: "youtube",

    description: "｢Utilidades｣  Faça uma pesquisa no Youtube.",

    type: Discord.ApplicationCommandOptionType.ChatInput,

    options: [

        {

            name: "pesquisa",

            description: "Qual pesquisa deseja fazer? lembre-se de nao dar espaços!",

            type: Discord.ApplicationCommandOptionType.String,

            required: false,

        }

    ],



    run: async(client, interaction) => {



        const pesq = interaction.options.getString("pesquisa");

        if (!pesq) return interaction.reply({ content: `Ei ${interaction.user}, Não achei nenhuma letra que você deseja procurar no **Youtube.** Por favor digite alguma coisa para te enviar a pesquisa.`, ephemeral: true })

        let pesquisa = `https://www.youtube.com/results?search_query=${pesq}`;



        let embed_boltzlindo = new Discord.EmbedBuilder()

        .setColor("#ff0000")

        .setTitle(`Search: ${pesq}`)

        .setDescription(`<:YouTube:1048902210622328863> Pesquisa encontrada!
> <:seta_vermelho:1047481726387109971> Achamos o resultado de ${pesq} Veja abaixo seu resultado!\n > <:seta_vermelho:1047481726387109971> [Resultado](${pesquisa})`)

        interaction.reply({embeds: [embed_boltzlindo], ephemeral: false })





    }

}