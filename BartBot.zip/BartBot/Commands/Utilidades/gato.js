const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "cat",

    description: "｢Utilidades｣  Envia a foto de um gato",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/cat`).then(response => response.json()).then(async(cat) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🐈 Gato`)

     .setDescription(`[Que gato fofo](${cat.image}).`)

     .setImage(cat.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};