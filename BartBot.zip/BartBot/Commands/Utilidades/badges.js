const { ApplicationCommandOptionType } = require("discord.js")

module.exports = {
    name: "badges",
    description: "｢Utilidades｣  Veja as insignas de um usuário.",
    options: [
        {
            name: "user",
            description: "Escolha um user",
            type: ApplicationCommandOptionType.User,
            required: false
        }
    ],
    run: async(client, interaction) => {

        let user = interaction.options.getUser("user") || interaction.user

        if(!user) {
            return interaction.reply({
                content: `**Não encontrei nenhum usuário parecido com ${interaction.options.getUser('user').username}**`,
                ephemeral: true
            })
        }

        let flags = user.flags.toArray()

        let flag2 = {
            "Staff": "<:staffbadge:1054916864066736128>",
            "Partner": "<:partner:1054916946031824936>",
            "Hypesquad": "<:HypeSquad_Events:1053807272620462180>",
            "BugHunterLevel1": "<:Bug_Hunter:1053807417596575847>",
            "BugHunterLevel2": "<:Bug_Hunter_Gold:1053807457551528036>",
            "HypeSquadOnlineHouse1": "<:bravery:1054906436574007376>",
            "HypeSquadOnlineHouse2": "<:brilliance:1054905723525550151>",
            "HypeSquadOnlineHouse3": "<:balance:1054906512482508860>",
            "PremiumEarlySupporter": "<:Early_Supporter:1053263259668598854>",
            "TeamPseudoUser": "nao sei",
            "VerifiedBot": "<:kk:1054923650073112607><:bot:1054923603210141827>",
            "VerifiedDeveloper": "<:botdev:1054917025148964914>",
            "CertifiedModerator": "<:Certified_Moderator:1051672828186992700>",
            "BotHttpInteractions": "<:Badge_Bot:1053812651689513001>",
            "ActiveDeveloper": "<:activedev:1054905892040101888>",
        }

        flags = flags.map(f => flag2[f]).join('')
        if (!flags) flags =  "O usuário selecionado nao possui nenhum tipo de insigna!", ephemeral: true

        interaction.reply({
            content: flags
        })

    }
}