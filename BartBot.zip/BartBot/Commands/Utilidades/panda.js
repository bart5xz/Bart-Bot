const Discord = require('discord.js');

const fetch = require('node-fetch');



module.exports = {

    name: "panda",

    description: "｢Utilidades｣  Envia a foto de um panda",

    run: async (client, interaction) => {



  await interaction.deferReply();



  fetch(`https://some-random-api.ml/animal/panda`).then(response => response.json()).then(async(panda) => {



    const e = new Discord.EmbedBuilder()

     .setTitle(`🐼 Panda`)

     .setDescription(`[Que panda fofo](${panda.image}).`)

     .setImage(panda.image)

     .setColor('Random')





  interaction.editReply({ embeds: [e] })



})



}};