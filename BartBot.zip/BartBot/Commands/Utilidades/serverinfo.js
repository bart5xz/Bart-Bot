const Discord = require("discord.js");



module.exports = {

    name: "serverinfo",

    description: "｢Utilidades｣  Veja as informações do servidor",

    type: Discord.ApplicationCommandType.ChatInput,


    run: async (client, interaction) => {
        



        let membros = interaction.guild.memberCount;

        let cargos = interaction.guild.roles.cache.size;

        let canais = interaction.guild.channels.cache.size;

        let entrou = interaction.guild.joinedTimestamp;

        let servidor = interaction.guild;

        let donoid = interaction.guild.ownerId;

        let emojis = interaction.guild.emojis.cache.size;

        let serverid = interaction.options.getString("id")

        let impulsos = interaction.guild.premiumSubscriptionCount;

        let data = interaction.guild.createdAt.toLocaleDateString("pt-br");





        let ryan = new Discord.EmbedBuilder()

            .setColor("5765F2")

            .setThumbnail(interaction.guild.iconURL({ dinamyc: true, format: "png", size: 4096 }))

            .setTitle(`Informações do servidor: ${interaction.guild}`)

            .addFields(

                {

                    name: `<:IconID:1050518904365129811> Identidade`,

                    value: `\`\`\`${interaction.guild.id}\`\`\``,

                    inline: true,

                },

                {

                    name: `<:IconStoreChannel:1050519365939904512> Canais em geral:`,

                    value: `<:IconTextChannel:1050518691822973019> Canais: ${canais}\n<:IconSettings:1050518710949003336> Cargos: ${cargos}`,

                    inline: true,

                },
                {

                    name: `<:IconMembers:1050519358281101332> Usuarios`,

                    value: `\`\`\`${membros} membros\`\`\``,

                    inline: true,

                },
                {

                    name: `🚀 Impulsos`,

                    value: `\`\`\`${impulsos} impulsos\`\`\``,

                    inline: true,

                },

                {

                    name: `<:IconNewsChannel:1050518720453288046> Servidor criado`,

                    value: `<t:${parseInt(interaction.guild.createdTimestamp / 1000)}>`,

                    inline: true,

                },

                {

                    name: `📃 ${interaction.user.username} entrou em `,

                    value: `<t:${parseInt(servidor.joinedTimestamp / 1000)}:F>`,

                    inline: true,

                },

                {

                    name: `<:IconCrown:1050518972216377494> Dono`,

                    value: `<@!${donoid}> \n\`\`${donoid}\`\``,

                    inline: true,

                }

        )

        

        

        

        

        interaction.reply({ embeds: [ryan] })

    }

}