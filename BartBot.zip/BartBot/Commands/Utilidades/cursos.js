const Discord = require('discord.js')

module.exports = {
    name: "cursos",
    description: "｢Utilidades｣  Veja cursos gratuitos e completos.",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        
        let js = "https://youtube.com/playlist?list=PLntvgXM11X6pi7mW0O4ZmfUI1xDSIbmTm"
        let py = "https://youtube.com/playlist?list=PLvE-ZAFRgX8hnECDn1v9HNTI71veL3oW0"
        let htmlcss = "https://youtube.com/playlist?list=PLHz_AreHm4dkZ9-atkcmcBaMZdmLHft8n"
        let c = "https://youtube.com/playlist?list=PLPc-V1ujthioJ8Cq_yMzYAbeSvaPye-aa"
        let php = "https://youtube.com/playlist?list=PLwXQLZ3FdTVEITn849NlfI9BGY-hk1wkq"
        let cmais = "https://youtube.com/playlist?list=PLx4x_zx8csUjczg1qPHavU1vw1IkBcm40"

        
        const embed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})
        .setTitle("Cursos gratuitos completos")
        .setColor('Black')
        .setDescription(`👋 Ola ${interaction.user}, **Você já sonhou em ser um grande programador?! aqui e a chance de você realizar esse sonho!, logo abaixo eu irei listar cursos de programação gratuitos e completos para você iniciar sua bela jornada!**
 
<:barthulk:1055083350869680138>  Cursos Free Completos:

> <:js_emoji2:1055122109606662235>  [Curso JavaScript](${js})
> <:python:1055121949153562666>  [Curso Python](${py})
> <:html_css:1055121999988523128>  [Curso Html e Css](${htmlcss})
> <:chasgt:1055123572798013541>  [Curso c#](${c})
> <:php:1055122364024750101>  [Curso Php](${php})
> <:cmais:1055122964342906921>  [Curso C++](${cmais})`)

        .setImage(`https://cdn.discordapp.com/attachments/1054820550381404231/1055120196265840680/images_1.jpeg`)
        .setTimestamp()

        interaction.reply({ embeds: [embed] })
    }
}
