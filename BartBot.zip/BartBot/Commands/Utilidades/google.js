const Discord = require("discord.js");



module.exports = {



    name: "google",



    description: "｢Utilidades｣  Faça uma pesquisa no Google.",



    type: Discord.ApplicationCommandType.ChatInput,



    options: [



        {



            name: "pesquisa",



            description: "Qual pesquisa deseja fazer?",



            type: Discord.ApplicationCommandOptionType.String,



            required: false,



        }



    ],



    run: async(client, interaction) => {



        const pesq = interaction.options.getString("pesquisa");



        if (!pesq) return interaction.reply({ content: `Hey ${interaction.user}! Não achei nenhuma letra que você deseja procurar no **Google.** Por favor digite alguma coisa para te enviar a pesquisa.`, ephemeral: true })



        let pesquisa = `https://www.google.com/search?q=${pesq}`;

        

        let embed_boltzlindo = new Discord.EmbedBuilder()

        .setColor("#5765F2")

        .setTitle(`Search: ${pesq}`)

        .setDescription(`<:google:1048903622504751124> Pesquisa encontrada!
> <:seta_vermelho:1047481726387109971> Achamos o resultado de ${pesq} Veja abaixo seu resultado!\n > <:seta_vermelho:1047481726387109971> [Clique Aqui](${pesquisa})`)

        interaction.reply({embeds: [embed_boltzlindo], ephemeral: false })



    }



}