const Discord = require("discord.js");

const axios = require("axios");

const DONO = "593798021247139840";

module.exports = {
  name: "logs",

  description: "｢Desenvolvedor｣ Mostra as logs mais recentes do bot.",

  type: 1,

  run: async (client, interaction, app) => {
      
      
              if (interaction.user.id !== DONO) return interaction.reply({ content: `<a:b_Spongebob_dance:1033929780501958708> | Esse comando e exclusivo apenas para criadores do bot!`, ephemeral: true })
      
      
    axios
      .get(`https://api.squarecloud.app/v1/public/logs/6b22f65b623145f09076e276d48ebe73`, {
        headers: {
          Authorization: "593798021247139840-c57332a86b80a5ca92a57055592784587332a3de065df5bf98f911d9bab02f23",
        },
      })
      .then(async (r) => {
        interaction.reply({
          content: `\`\`\`js\n${r.data.response.logs.slice(0, 1800)}\`\`\``,
        });
      })
      .catch(async (error) => {
        console.log(error);
      });
  },
}; 
