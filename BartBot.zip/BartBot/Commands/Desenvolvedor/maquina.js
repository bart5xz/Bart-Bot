const fs = require("fs");

const osu = require('node-os-utils')

const cpu = osu.cpu

const mem = osu.mem

const os = osu.os

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const DONO = "593798021247139840";

 

module.exports = {

 

    name: "maquina",

    description: "｢Informacoes｣ Fornece informações sobre a máquina.",

    permission: "None",

    dm: false,

    category: ":point_up_2_tone1:Information",

 

    async run(bot, message) {
        
        if (message.user.id !== DONO) return message.reply({ content: `<a:b_Spongebob_dance:1033929780501958708> | Esse comando e exclusivo apenas para criadores do bot!`, ephemeral: true })

 

        try {

 

            await message.deferReply()

 

            const cpuUsage = (await cpu.usage()) + "%";

            const memoryUsage = (await mem.info()).usedMemMb + "MB";

            const memoryfree = (await mem.info()).freeMemMb + "MB";

            const memoryUsageTotal = (await mem.info()).totalMemMb + "MB";

            const operatingSystemName = `${os.hostname()}`

 

 

            const row = new ActionRowBuilder()

                .addComponents(

                    new ButtonBuilder()

                        .setLabel("Convida-me")

                        .setStyle(ButtonStyle.Link)

                        //Coloque o link do seu bot

                        .setURL("https://discord.com/api/oauth2/authorize?client_id=1046240076797059162&permissions=8&scope=bot%20applications.commands")

                )

            const Embed = new EmbedBuilder()

                .setColor("#5765F2")

                .setTitle(`<a:load:1049036111177056397> | Carregamento de informação na máquina do bot.`)

                .setThumbnail(bot.user.displayAvatarURL({ dynamic: true, size: 64 }))

                .setDescription(`**__Estou à procura de informações da máquina__**

 

> **No servidor :** ${message.guild.name}, 

 

                \`Por favor aguarde\`...`)

                .setTimestamp()

                .setFooter({ text: "Estatísticas" })

 

            await message.followUp({ embeds: [Embed] }).then(() => {

 const embed = new EmbedBuilder()

                    .addFields(

                        { name: "> ** <:pc:1041696888040210502> Cpu: **", value: `> ${cpuUsage}`, inline: true },

                        { name: "> ** <:memoryram:1049036370246639708> Ram : **", value: `> Total: \`${memoryUsageTotal}\`\n> Usado: \`${memoryUsage}\`\n> Restante: \`${memoryfree}\``, inline: true },

                        { name: "> ** <:desc:1041069919070064742> Info:**", value: `> Host local: \`${operatingSystemName}\``, inline: true }

                    )

                    .setColor("#5765F2")

                    .setThumbnail(bot.user.displayAvatarURL({ dynamic: true, size: 64 }))

                    .setTimestamp()

                    .setFooter({ text: "Estatísticas" })

 

                setTimeout(async () => await message.editReply({ embeds: [embed], components: [row] }), 2000)

                setInterval

            })

        } catch (err) {

 

            console.log(`Um erro na ordem Estatísticas.`, err)

 

            fs.writeFile("./error.txt", `${err.stack} `, () => {

                return

            })

 

            let channel = await bot.channels.cache.get("1048627037885186048")/// O id do canal

            channel.send({ content: `⚠️ Apareceu um erro! Sobre o  ${message.guild.name}!`, files: [{ attachment: './error.txt', name: 'error.txt', description: "O erro resultante" }] })

        }

 

    }

}