const Discord = require("discord.js");
const { joinVoiceChannel } = require("@discordjs/voice");

const DONO = "593798021247139840"; // Coloque seu ID

module.exports = {
    name: "call",
    description: "｢Desenvolvedor｣ Me conecta em um canal de voz!",
    options: [
        {
            name: "canal",
            description: "Coloque o canal de voz.",
            type: Discord.ApplicationCommandOptionType.Channel,
            channelTypes: [
                Discord.ChannelType.GuildVoice,
            ],
            required: true
        }
    ],

    run: async (client, interaction) => {
        let canal = interaction.options.getChannel('canal');

        joinVoiceChannel({
            channelId: canal.id,
            guildId: canal.guild.id,
            adapterCreator: canal.guild.voiceAdapterCreator
        })

if (interaction.user.id !== DONO) return interaction.reply({ content: `**<a:b_Spongebob_dance:1033929780501958708> | Esse comando e exclusivo apenas para criadores do bot!**`, ephemeral: true })


        const embed = new Discord.EmbedBuilder()
        .setColor('#5765F2')
        .setDescription(`**<a:Tony:1041069368529915914> | ${interaction.user},conectei no canal de voz: ${canal}** com Sucessso!`)
        interaction.reply({ embeds: [embed] })
    }
} 
