const dc = require("discord.js")



module.exports = {

    name: 'deathnote',

    description: '｢Diversoes｣ Anote uma pessoa no deathnote.',

    type: 1,

    options: [{name: 'alvo', description: 'Coloque o alvo do comando.', type: 6, required: true }],

    run: async (client, interaction, args) => {



        const alvo = interaction.options.getUser('alvo'); //Usuário mencionado



        if(alvo.id === interaction.user.id) return interaction.reply({ content: `❌ Você não pode se colocar no death note.`, ephemeral: true})

        

        const gifs1 = ['https://c.tenor.com/4LmyhIwaSpMAAAAM/death-note-kira.gif','https://gifs.eco.br/wp-content/uploads/2022/07/gifs-de-death-note-9.gif',

        'https://i.gifer.com/24BJ.gif','https://c.tenor.com/410D2hl5hjgAAAAC/death-note-death-note-book.gif','https://img1.picmix.com/output/pic/normal/6/4/6/5/4265646_22473.gif'];



        const gifs2 = ['https://animesher.com/orig/1/139/1395/13951/animesher.com_gif-death-note-kira-1395114.gif','https://64.media.tumblr.com/tumblr_lkozrjVuep1qgzdf6.gif','https://i.gifer.com/embedded/download/DU2.gif',

        'http://pa1.narvii.com/6579/0aabe9b1cade73e6e1edec68054723b17a4c252a_00.gif','https://thumbs.gfycat.com/DecisiveEnormousBrahmancow-size_restricted.gif','https://pa1.narvii.com/6941/4d33b629e7437221e82f7b7e0495c885ab09212dr1-500-320_hq.gif',];



        let deathgif = gifs1[Math.floor(Math.random() * gifs1.length)];

        let deathgif2 = gifs2[Math.floor(Math.random() * gifs2.length)];



        const e1 = new dc.EmbedBuilder()

        .setDescription(`<:kira:1050797831209877536> | ${interaction.user} Anotou o nome de ${alvo} no death note.`)

        .setImage(deathgif)

        .setColor(`Random`)

        .setTimestamp(new Date())



            const b1 = new dc.ActionRowBuilder().addComponents(

                new dc.ButtonBuilder()

                .setCustomId('rv')

                .setLabel('Inverter')

                .setStyle(4)

                .setEmoji(`🔂`)

            );

            const e2 = new dc.EmbedBuilder()

            .setDescription(`<:Lawliet:1050797745948082236> | ${alvo} Colocou o nome de ${interaction.user} no death note, quebrando o feitiço.`)

            .setColor(`Random`)

            .setImage(deathgif2)

            .setTimestamp(new Date())

           

            interaction.reply({ embeds: [e1], components: [b1] }).then(() => {

            const coll = interaction.channel.createMessageComponentCollector({ max: 1 });

    

            coll.on('collect', async (cc) => {

                if(cc.user.id !== alvo.id) {return;}

                    

                else if (cc.customId === 'rv') {

                    cc.reply({ embeds: [e2] }) }

})

})

}} // https://discord.gg/seeNNdJn5K