const Discord = require('discord.js')

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandType, ButtonStyle } = require('discord.js');

module.exports = {
    name: "nitro",
    description: "｢Diversoes｣ Gera um nitro troll para se divertir.",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        
        
        const embed = new Discord.EmbedBuilder()
     
        .setColor("#FF44E4")
        .setDescription(`${interaction.user} **Você recebeu 1 ano de Nitro Gamming!**`)
        .setImage(`https://cdn.discordapp.com/attachments/1054820550381404231/1055148310429712404/11111unknown.png`)

        const ButtonNews = new ActionRowBuilder()

        .addComponents([

          new ButtonBuilder()

            .setEmoji('<a:nitrogaming:1055153182113796137>')

            .setLabel('Resgatar')

            .setURL(`https://cdn.discordapp.com/attachments/1054820550381404231/1055150216447266906/download.jpeg`)

            .setStyle(ButtonStyle.Link)

        ])



        interaction.reply({ embeds: [embed], components: [ButtonNews] })

    }

}
