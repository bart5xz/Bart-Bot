const dc = require("discord.js");



module.exports = {

    name: '8ball',

    description: '｢Diversoes｣ Faça perguntas para o BartBot!',

    type: 1,

    options: [{ name: `pergunta`, description: `Digite a sua pergunta`, type: 3, required: true }],



    run: async (client, interaction, app) => {



    const pergunta = interaction.options.getString("pergunta");



    if(!pergunta.endsWith("?")) {



        const semPergunta = new dc.EmbedBuilder()

        .setDescription(`**❌ O seu comentário precisar ser uma pergunta! \`?\`**`)

        .setColor("#e90404")



        return interaction.reply({ embeds: [semPergunta] })

    }



    const array = ["Não", "Sim", "Não sei", "Tanto faz", "Pergunta no posto ipiranga", "Hmm...", "Não pergunte a mim", "Não quero ferir seu coração", "Não gosto desse tipo de pergunta", "Lá ele", "Legal", "Não acredito nisso", "???", "Sla", "Melhor não te dizer agora", "Pergunte novamente mais tarde", "Chulispa patrão", "Hmmm Pergunta Sus🤨"];



    const e = new dc.EmbedBuilder()

    .setAuthor({ name: `8Ball`, iconURL: `https://cdn.discordapp.com/attachments/1054820550381404231/1055182835440427058/bart_simpson_001-removebg-preview.png`})

    .setDescription(`${array[Math.floor (Math.random() * array.length)]}.`)

    .setColor("#5765F2")



    interaction.reply({ embeds: [e] })

}}; 