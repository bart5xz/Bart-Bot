const Canvas = require('canvas')

const Discord = require("discord.js")



module.exports = {



    name: "conquista-xbox",

    description: "｢Utilidades｣ Desbloquear conquista xbox.",

    type: Discord.ApplicationCommandType.ChatInput,

    options: [

            {

             name: "conquista",

             description: "Mande sua conquista!",

             type: Discord.ApplicationCommandOptionType.String,

             required: true

            }

            ],



    run: async (client, interaction, args, storage) => {



        let msg = interaction.options.getString('conquista')

        

        if (msg.length > 25) {



            return interaction.reply({ content: `**❌ - Ahhhh! Por favor escreva um texto com no maximo \`25\` letras**`, ephemeral: true })

        } else {



        const canvas = Canvas.createCanvas(1018, 560)

        const ctx = canvas.getContext("2d")



        const xbox = await Canvas.loadImage(`https://cdn.discordapp.com/attachments/1016929140747808848/1038985166074433557/conquistaXbox.png`)

        

        

        ctx.drawImage(xbox, 0, 0, canvas.width, canvas.height)

        ctx.font = "48px sans-serif"

        ctx.fillStyle = "#d8d8d8";

        if(msg.length <8) {

            ctx.fillText(`${msg}`, 425, 349)





            const attachment = new Discord.AttachmentBuilder(canvas.toBuffer(), { name: "xbox.png"})

            let embedXbox = new Discord.EmbedBuilder()

             .setColor("Green")

             .setImage("attachment://xbox.png")

    

            interaction.reply({ files: [attachment], content: `**${interaction.user}sua conquista abaixo!**`, embeds: [embedXbox] })

        }else {

            ctx.fillText(`${msg}`, 236, 349)





            const attachment = new Discord.AttachmentBuilder(canvas.toBuffer(), { name: "xbox.png"})

            let embedXbox = new Discord.EmbedBuilder()

             .setColor("Green")

             .setImage("attachment://xbox.png")

    

            interaction.reply({ files: [attachment], content: `**🔔 ${interaction.user}, nova conquista desbloqueada!**`, embeds: [embedXbox] })

        }

        



    }

}

}