const client = require('..');

client.on("", async () => {
                const activities = [
        { name: `/help | BartBot.gg`, type: 1 },
        //{ name: `💻 ${client.users.cache.size} usuários`, type: 0 }
        ];
        const status = ['idle'];

        let i = 0;
        setInterval(() => {
            if(i >= activities.length) i = 0
            client.user.setActivity(activities[i])
            i++;
        }, 15 * 1000);
        
        let s = 0;  
});    
