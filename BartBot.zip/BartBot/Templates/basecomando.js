const Discord = require('discord.js')

module.exports = {
    name: "",
    description: "",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        
        
        const embed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${client.user.username}`, iconURL: `${client.user.displayAvatarURL()}`})
        .setTitle(``)
        .setColor(``)
        .setDescription(``)
        .setImage(``)
        .setFooter(``)
        .setThumbnail(``)
        .setTimestamp()

        interaction.reply({ embeds: [embed] })
    }
}
